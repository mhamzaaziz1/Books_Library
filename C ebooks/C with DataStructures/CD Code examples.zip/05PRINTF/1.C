#include <stdio.h>
main()
{
int i = 0;
i=printf("abcde");	// A
printf("total characters printed %d\n",i);  //B
}
