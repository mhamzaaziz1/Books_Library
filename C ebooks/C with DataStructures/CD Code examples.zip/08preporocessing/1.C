# include <stdio.h>

#define VAL 35		// A
#define HELLO �HELLO�;	// B

main ()
{	
	int res;

	res = VAL-5;		// C
	printf (�res = VAL-5: res == %d\n�, res);
	
	printf ( HELLO);		//D
}
