#include <stdio.h>
main()
{
printf("Hello \n"); /* prints Hello on standard output */
}
