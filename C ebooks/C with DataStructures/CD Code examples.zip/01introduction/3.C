#include <stdio.h>
main()
{
int i,j,k;  
scanf("%d%d",&i,&j);  // statement A
k = i + j;
printf("sum of two numbers is %d \n",k);
}

