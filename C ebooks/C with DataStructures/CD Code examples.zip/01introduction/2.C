#include <stdio.h>
main()
{
int i,j,k; // Defining variables  Statement A
i = 6;    // Statement  B
j = 8;
k = i + j;
printf("sum of two numbers is %d \n",k); // Printing results
}

