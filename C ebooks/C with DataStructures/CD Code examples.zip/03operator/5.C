 #include<stdio.h>
 
 main()
 {
   int i,j,k;
   k = (i = 4, j = 5);
   printf("k = %d",k);
  }
