 #include<stdio.h>
 
 main( )
{
  int I,j,k;
 i = 3;
 j =4;
 k = i++ +  --j;
 printf("i = %d, j = %d, k = %d",i,j,k);
 }
