#include <stdio.h>
main ()
{
	int i, j, k;	//A
            i = 10;		//B
	j = 20;		//C
	k = i + j;	//D
	
	printf (�Value of k is %d\n�, k);
}
